<?php include 'template/header.php'?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <script>
                function solonumeros(e){
                    key=e.keycode || e.which;
                    teclado=string.fromCharCode(key);
                    numeros="0123456789";
                    especiales="8-37-38-46";
                    teclado_especiales=false;

                    for(var i in especiales){
                        if (key==especiales[i]){
                            teclado_especial=true;
                        }
                    }
                    if(numeros.indexof(teclado)==-1&&!teclado_especial){
                        return false;

                    }
                }
            </script>
        
            
        </div>
    
        <div class="card">
            <div class="card-header text-center">
                <strong>HISTORIAL DE MOVIMIENTOS</strong> 
            </div>
            <div class="p4">
                <table class="table align-center">
                    <thead>
                        <tr>
                           <th scope="col">#</th>
                            <th scope="col">ADELANTE</th>
                            <th scope="col">STOP</th>
                            <th scope="col">ATRAS</th>
                            <!--<th scope="col" colspan="2">Opciones</th>-->
                        </tr>
                    </thead>
                    <!--conexion con la base de datos generada con firebase-->
                    <script type="module">
                    // Import the functions you need from the SDKs you need
                    import { initializeApp } from "https://www.gstatic.com/firebasejs/9.14.0/firebase-app.js";
                    import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.14.0/firebase-analytics.js";
                    // TODO: Add SDKs for Firebase products that you want to use
                    // https://firebase.google.com/docs/web/setup#available-libraries

                    // Your web app's Firebase configuration
                    // For Firebase JS SDK v7.20.0 and later, measurementId is optional
                    const firebaseConfig = {
                        apiKey: "AIzaSyD86WYOIdUNKyj2JXW-e-ueXNwtop1LSME",
                        authDomain: "db-ds-914d1.firebaseapp.com",
                        databaseURL: "https://db-ds-914d1-default-rtdb.firebaseio.com",
                        projectId: "db-ds-914d1",
                        storageBucket: "db-ds-914d1.appspot.com",
                        messagingSenderId: "822457199220",
                        appId: "1:822457199220:web:57798f0d8b22cc4e89bf21",
                        measurementId: "G-J1DC2MFX3K"
                    };

                    // Initialize Firebase
                    const app = initializeApp(firebaseConfig);
                    const analytics = getAnalytics(app);
                    <?php 
                           
                        foreach($movimiento as $dato){    
                        ?>
                        // Almacenamos los datos en la base de datos en firebase y mostramos en la pagina web.
                        <tr>
                        
                            <td scope="row"><?php echo $dato->codigo; ?></td>
                            <td><?php echo $dato->FORWARD; ?></td>
                            <td><?php echo $dato->STOP; ?></td>
                            <td><?php echo $dato->BACK; ?></td>
                            <?php 
                            }
                            ?>
                    </script>
                </table>         
            </div>
        </div>
    </div>
</div>                       
<?php include 'template/footer.php'?>
