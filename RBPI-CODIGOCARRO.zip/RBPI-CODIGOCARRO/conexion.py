
import firebase_admin
from firebase_admin import cedentials
from firebase_admin import firestore
import time
import controlGPIO


cred = credentials.Certificate("Keydb")
firebase_admin.initialize_app(cred)

try:
   firebase_admin.fet_app()
except:
    default_app = firebase_admin.initialize_app(cred)


db = firestore.client()

doc_ref = db.collection(u'sensor').document(u'AIzaSyD86WYOIdUNKyj2JXW-e-ueXNwtop1LSME')


while True:
    try:
        doc_ref.get().to_dict().get('accion')
        print(doc)

        controlGPIO.mover_carro(doc)

    except google.cloud.expeptions.NotFound:
        print(u'no such document')
    time.sleep(0.2)