import RPi.GPIO as GPIO          
from time import sleep

motor1f = 16
motor1a = 18
motor2f= 31
motor2a=29

GPIO.setmode(GPIO.BOARD)
GPIO.setup(motor1f,GPIO.OUT)
GPIO.setup(motor1a,GPIO.OUT)
GPIO.setup(motor2f,GPIO.OUT)
GPIO.setup(motor2a,GPIO.OUT)
while True:

    valor=int(input())
    
    if valor==1:
        GPIO.output(motor1f,GPIO.HIGH)
        GPIO.output(motor1a,GPIO.LOW)
        GPIO.output(motor2f,GPIO.HIGH)
        GPIO.output(motor2a,GPIO.LOW)
        print("Adelante")
        valor=4

    elif valor==2:
        print("Atras")
        GPIO.output(motor1f,GPIO.LOW)
        GPIO.output(motor1a,GPIO.HIGH)
        GPIO.output(motor2f,GPIO.LOW)
        GPIO.output(motor2a,GPIO.HIGH)
        valor=4

    elif valor==0:
        print("STOP")
        GPIO.output(motor1f,GPIO.LOW)
        GPIO.output(motor1a,GPIO.LOW)
        GPIO.output(motor2f,GPIO.LOW)
        GPIO.output(motor2a,GPIO.LOW)
        
        valor=4
    elif valor==5:
        GPIO.cleanup()
        
        valor=4
    

