package com.udem.miApp.Controller;

import com.udem.miApp.Services.PostManagentServices;
import com.udem.miApp.dto.PostDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication
@RequestMapping(value="/controller")
public class PostController {
        @Autowired
        private PostManagentServices service;
        @GetMapping(value="/greet/{name}")
        public String greet(@PathVariable(value = "name")String name) {
                return "Hello " + name;
        }
        @GetMapping(value="/list")
        public ResponseEntity list() {
                return new ResponseEntity(null, HttpStatus.OK);
        }
        @PostMapping(value = "/add")
        public ResponseEntity add(@RequestBody PostDTO post) {
                return new ResponseEntity(service.add(post), HttpStatus.OK);

        }
        @PutMapping(value = "/{id}/update")
        public ResponseEntity update(@PathVariable(value = "id") String id, @RequestBody PostDTO post) {
                return new ResponseEntity(service.update(id,post), HttpStatus.OK);
        }
        @DeleteMapping(value = "/{id}/delete")
        public ResponseEntity delete(@PathVariable(value = "id") String id) {
                return new ResponseEntity(null, HttpStatus.OK);
        }
}
