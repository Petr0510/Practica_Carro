package com.udem.miApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiAppApplication.class, args);
	}

}
