package com.udem.miApp.Services;

import com.udem.miApp.dto.PostDTO;

import java.util.List;

public interface PostManagentServices {
    List<PostDTO> list();
    Boolean add(PostDTO post);
    Boolean update(String id,PostDTO post);
    Boolean delete(String id);
}

