package com.udem.miApp.dto;

import lombok.Data;

@Data
public class PostDTO {
    private String id;
    
    private int movimiento;
    
	public int getMovimiento() {
		return movimiento;
	}
	public void setMovimiento(int movimiento) {
		this.movimiento = movimiento;
	}
    

}
