package com.udem.miApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
